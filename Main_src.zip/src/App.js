import React from 'react';
import MachineChatbot from './MachineChatbot';

function App() {
  return (
    <div className="App">
      <MachineChatbot />
    </div>
  );
}

export default App;
