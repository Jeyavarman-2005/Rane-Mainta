import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { FiSend, FiSettings, FiSave, FiDownload, FiUpload, FiMessageSquare, FiUser, FiCpu } from 'react-icons/fi';
import { BsLightningFill, BsDatabase } from 'react-icons/bs';
import { RiRobot2Line } from 'react-icons/ri';
import { MdOutlineAttachFile } from 'react-icons/md';
import './MachineChatbot.css';

const MachineChatbot = () => {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [conversations, setConversations] = useState([]);
  const [activeConversation, setActiveConversation] = useState(null);
  const [showSidebar, setShowSidebar] = useState(true);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [apiEndpoint, setApiEndpoint] = useState('http://localhost:8000/api/chat');
  const [darkMode, setDarkMode] = useState(true);
  const [selectedFile, setSelectedFile] = useState(null);
  const [exampleQuestions, setExampleQuestions] = useState([]);
  const [sourceFilter, setSourceFilter] = useState('all');
  
  const messagesEndRef = useRef(null);

  // Function to format text with markdown-like syntax
  const formatText = (text) => {
    if (!text) return text;
    
    // Replace **text** with bold
    let formattedText = text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    
    // Replace ### text with heading
    formattedText = formattedText.replace(/^### (.*$)/gm, '<h3>$1</h3>');
    
    return formattedText;
  };

  // Component to render formatted text
  const FormattedText = ({ text }) => {
    const formatted = formatText(text);
    return <div dangerouslySetInnerHTML={{ __html: formatted }} />;
  };

  useEffect(() => {
    const savedConversations = localStorage.getItem('machine-chat-conversations');
    if (savedConversations) {
      setConversations(JSON.parse(savedConversations));
    }
    
    fetchExampleQuestions();
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const fetchExampleQuestions = async () => {
    try {
      const response = await axios.get('http://localhost:8000/api/examples');
      setExampleQuestions(response.data.examples);
    } catch (err) {
      console.error("Couldn't fetch example questions:", err);
      setExampleQuestions([
        "Show me recent breakdowns of IBJ Assy - 02",
        "What is the MTBF for machine 10009627?",
        "List electrical issues from last week",
        "Compare downtime between Plant 1150 and 1151"
      ]);
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMessage = {
      id: Date.now(),
      text: input,
      sender: 'user',
      timestamp: new Date().toISOString()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setLoading(true);
    setError(null);

    try {
      const response = await axios.post(apiEndpoint, {
        question: input  // Changed from 'query' to 'question' to match FastAPI endpoint
      });

      const botMessage = {
        id: Date.now() + 1,
        text: response.data.answer || response.data.response, // Handle both response formats
        sender: 'bot',
        timestamp: new Date().toISOString(),
        sources: response.data.sources || [],
        processingTime: response.data.processing_time,
        breakdownType: response.data.breakdown_type
      };

      setMessages(prev => [...prev, botMessage]);
    } catch (err) {
      console.error("API Error:", err);
      setError(err.response?.data?.detail || err.message);
      const errorMessage = {
        id: Date.now() + 1,
        text: 'Error: ' + (err.response?.data?.detail || err.message || 'Failed to get response'),
        sender: 'error',
        timestamp: new Date().toISOString()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setLoading(false);
    }
  };

  const saveConversation = () => {
    if (messages.length === 0) return;

    const firstUserMessage = messages.find(m => m.sender === 'user');
    const title = firstUserMessage 
      ? firstUserMessage.text.slice(0, 30) + (firstUserMessage.text.length > 30 ? '...' : '')
      : `Conversation ${conversations.length + 1}`;

    const newConversation = {
      id: Date.now(),
      title: title,
      messages: [...messages],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    const updatedConversations = [...conversations, newConversation];
    setConversations(updatedConversations);
    localStorage.setItem('machine-chat-conversations', JSON.stringify(updatedConversations));
  };

  const loadConversation = (conversationId) => {
    const conversation = conversations.find(c => c.id === conversationId);
    if (conversation) {
      setMessages(conversation.messages);
      setActiveConversation(conversationId);
    }
  };

  const exportConversations = () => {
    const dataStr = JSON.stringify(conversations, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `machine-chat-conversations-${new Date().toISOString()}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = JSON.parse(event.target.result);
        if (Array.isArray(data)) {
          setConversations(data);
          localStorage.setItem('machine-chat-conversations', JSON.stringify(data));
        }
      } catch (err) {
        setError('Invalid file format');
      }
    };
    reader.readAsText(file);
    setSelectedFile(file.name);
  };

  const clearConversation = () => {
    setMessages([]);
    setActiveConversation(null);
  };

  const suggestQuestion = (question) => {
    setInput(question);
  };

  const renderSources = (sources) => {
    if (!sources || sources.length === 0) return null;

    const filteredSources = sourceFilter === 'all' 
      ? sources 
      : sources.filter(source => source.breakdown_type?.toLowerCase() === sourceFilter.toLowerCase());

    if (filteredSources.length === 0) {
      return <div className="no-sources">No {sourceFilter} sources found</div>;
    }

    return (
      <div className="sources-container">
        <div className="sources-header">
          <h4>Reference Data</h4>
          <select 
            value={sourceFilter} 
            onChange={(e) => setSourceFilter(e.target.value)}
            className="source-filter"
          >
            <option value="all">All Types</option>
            <option value="mechanical">Mechanical</option>
            <option value="electrical">Electrical</option>
            <option value="hydraulic">Hydraulic</option>
            <option value="pneumatic">Pneumatic</option>
          </select>
        </div>
        
        <div className="sources-grid">
          {filteredSources.map((source, index) => (
            <div key={index} className="source-card">
              <div className="source-card-header">
                <h5>{source.machine || 'Unknown Machine'}</h5>
                <span className={`breakdown-tag ${source.breakdown_type?.toLowerCase() || 'other'}`}>
                  {source.breakdown_type || 'Unknown Type'}
                </span>
              </div>
              <div className="source-card-body">
                <p><strong>SAP Code:</strong> {source.sap_code || 'N/A'}</p>
                <p><strong>Location:</strong> {source.plant} / {source.shop}</p>
                <p><strong>Time:</strong> {source.start_time || 'N/A'} ({source.duration || 'N/A'})</p>
                <p><strong>Problem:</strong> {source.problem_type || 'N/A'}</p>
                <p><strong>Root Cause:</strong> {source.actual_reason || 'N/A'}</p>
                <p><strong>Resolution:</strong> {source.closure_reason || 'N/A'}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className={`chatbot-container ${darkMode ? 'dark-mode' : ''}`}>
      <div className={`sidebar ${showSidebar ? 'open' : ''}`}>
        <div className="sidebar-header">
          <RiRobot2Line className="sidebar-icon" />
          <h3>Machine Chat</h3>
          <button onClick={() => setShowSidebar(false)} className="close-sidebar">
            &times;
          </button>
        </div>
        
        <div className="conversation-list">
          {conversations.length > 0 ? (
            conversations.map(conv => (
              <div 
                key={conv.id} 
                className={`conversation-item ${activeConversation === conv.id ? 'active' : ''}`}
                onClick={() => loadConversation(conv.id)}
              >
                <FiMessageSquare className="conversation-icon" />
                <div className="conversation-info">
                  <span className="conversation-title">{conv.title}</span>
                  <span className="conversation-date">
                    {new Date(conv.createdAt).toLocaleDateString()}
                  </span>
                </div>
              </div>
            ))
          ) : (
            <div className="empty-conversations">
              <p>No saved conversations</p>
            </div>
          )}
        </div>
        
        <div className="sidebar-actions">
          <button onClick={saveConversation} className="action-button">
            <FiSave /> Save
          </button>
          <button onClick={clearConversation} className="action-button">
            <FiMessageSquare /> New
          </button>
          <div className="file-upload-wrapper">
            <label htmlFor="file-upload" className="action-button">
              <FiUpload /> Import
            </label>
            <input 
              id="file-upload" 
              type="file" 
              accept=".json" 
              onChange={handleFileUpload}
              style={{ display: 'none' }}
            />
            {selectedFile && <span className="file-name">{selectedFile}</span>}
          </div>
          <button onClick={exportConversations} className="action-button">
            <FiDownload /> Export
          </button>
        </div>
      </div>
      
      <div className="chat-main">
        <div className="chat-header">
          <button 
            onClick={() => setShowSidebar(!showSidebar)} 
            className="menu-button"
          >
            ☰
          </button>
          <h2>
            <BsDatabase className="header-icon" /> Machine Data Assistant
          </h2>
          <div className="header-actions">
            <button 
              onClick={() => setSettingsOpen(!settingsOpen)}
              className={`settings-button ${settingsOpen ? 'active' : ''}`}
            >
              <FiSettings />
            </button>
            <button 
              onClick={() => setDarkMode(!darkMode)}
              className="theme-toggle"
            >
              {darkMode ? '☀️' : '🌙'}
            </button>
          </div>
        </div>
        
        {settingsOpen && (
          <div className="settings-panel">
            <h4>API Settings</h4>
            <div className="setting-item">
              <label>Endpoint URL:</label>
              <input 
                type="text" 
                value={apiEndpoint}
                onChange={(e) => setApiEndpoint(e.target.value)}
                placeholder="Enter API endpoint"
              />
            </div>
            <div className="setting-item">
              <label>Dark Mode:</label>
              <input 
                type="checkbox" 
                checked={darkMode}
                onChange={() => setDarkMode(!darkMode)}
              />
            </div>
          </div>
        )}
        
        <div className="chat-messages">
          {messages.length === 0 ? (
            <div className="welcome-screen">
              <div className="welcome-content">
                <RiRobot2Line className="welcome-icon" />
                <h3>Machine Data Assistant</h3>
                <p>Ask questions about your industrial machines, maintenance records, production data, and more.</p>
                
                <div className="quick-questions">
                  <h4>Try asking:</h4>
                  {exampleQuestions.map((q, i) => (
                    <div 
                      key={i} 
                      className="suggested-question"
                      onClick={() => suggestQuestion(q)}
                    >
                      <BsLightningFill className="lightning-icon" />
                      {q}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            messages.map((message) => (
              <div 
                key={message.id} 
                className={`message ${message.sender}`}
              >
                <div className="message-sender">
                  {message.sender === 'user' ? (
                    <FiUser className="sender-icon" />
                  ) : message.sender === 'error' ? (
                    <span className="error-icon">⚠️</span>
                  ) : (
                    <FiCpu className="sender-icon" />
                  )}
                </div>
                <div className="message-content">
                  <pre className="preformatted-text">
                    <FormattedText text={message.text} />
                  </pre>
                  {message.sender === 'bot' && message.processingTime && (
                    <div className="processing-time">
                      Generated in {message.processingTime}
                      {message.breakdownType && (
                        <span className="breakdown-hint">
                          (Mainly {message.breakdownType} issues)
                        </span>
                      )}
                    </div>
                  )}
                  {message.sender === 'bot' && renderSources(message.sources)}
                  <div className="message-time">
                    {new Date(message.timestamp).toLocaleTimeString()}
                  </div>
                </div>
              </div>
            ))
          )}
          {loading && (
            <div className="message bot">
              <div className="message-sender">
                <FiCpu className="sender-icon" />
              </div>
              <div className="message-content">
                <div className="loading-dots">
                  <div></div>
                  <div></div>
                  <div></div>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
        
        <form onSubmit={handleSubmit} className="chat-input-area">
          <div className="file-attach">
            <label htmlFor="file-attach-input">
              <MdOutlineAttachFile className="attach-icon" />
            </label>
            <input 
              id="file-attach-input" 
              type="file" 
              style={{ display: 'none' }}
            />
          </div>
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about machine data..."
            disabled={loading}
            className="chat-input"
          />
          <button 
            type="submit" 
            disabled={loading || !input.trim()}
            className="send-button"
          >
            {loading ? (
              <div className="spinner"></div>
            ) : (
              <FiSend className="send-icon" />
            )}
          </button>
        </form>
      </div>
    </div>
  );
};

export default MachineChatbot;